<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Notifications;

class NotificationsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        {
            /*Notifications::create([
                'sent_by' => 'Sistema',
                'receiver_id' => null,
                'visible_to_permissions' => 'all',
                'title' => 'Mensagem do Sistema',
                'message' => 'Mensagem Global 1 do administrador',
                'button_route' => '',
                'button_label' => '',
                'created_at' => now(),
                'updated_at' => now(),
            ]);*/
        }
    }
}
