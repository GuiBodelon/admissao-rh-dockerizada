<?php

use PhpOffice\PhpExcel\Settings;

Settings::setZipClass(Settings::PCLZIP);

?>
